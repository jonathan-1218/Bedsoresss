
import React from "react";

const SENSOR_LAYOUT = {
  S1: { top: "10%", left: "50%" },
  S2: { top: "30%", left: "25%" },
  S3: { top: "30%", left: "75%" },
  S4: { top: "50%", left: "50%" },
  S5: { top: "70%", left: "25%" },
  S6: { top: "70%", left: "75%" },
};

const Sensor = ({ id, style }) => (
  <div style={{
    position: "absolute",
    transform: "translate(-50%, -50%)",
    padding: "10px",
    background: "red",
    color: "white",
    borderRadius: "8px",
    ...style
  }}>
    {id}
  </div>
);

export default function App() {
  return (
    <div style={{ width: "100vw", height: "100vh", background: "#111", position: "relative" }}>
      {Object.entries(SENSOR_LAYOUT).map(([id, pos]) => (
        <Sensor key={id} id={id} style={pos} />
      ))}
    </div>
  );
}
